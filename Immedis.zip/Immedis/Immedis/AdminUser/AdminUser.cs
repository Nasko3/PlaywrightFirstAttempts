﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Immedis.AdminUser
{
    public class AdminUser
    {
        public string User;
        public string Password;
        public AdminUser(string user, string password)
        {
            User = user;
            Password = password;
        }
        public static AdminUser TestUser = new AdminUser("", "");
       // public static AdminUser TestUser = new AdminUser("admin", "123456");
    }
}