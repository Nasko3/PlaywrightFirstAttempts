﻿namespace Immedis.Driver
{
    enum Browsers
    {
        Chrome,
        Firefox
    }
}