﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Immedis.Page
{
    public class BooksPage : BasePage
    {
        private IWebElement pageTitle => Driver.FindElement(By.TagName("h2"));
        private IWebElement pageBooks => Driver.FindElement(By.XPath("//a[@href='/Books']"));
        private IWebElement libraryNavBar => Driver.FindElement(By.ClassName("navbar-brand"));
        private IWebElement createNewBookButton => Driver.FindElement(By.LinkText("Create New"));
        private IWebElement bookNameField => Driver.FindElement(By.CssSelector("input#Name"));
        private IWebElement bookAuthorField => Driver.FindElement(By.CssSelector("input#Author"));
        private IWebElement bookGenereField => Driver.FindElement(By.CssSelector("input#Genre"));
        private IWebElement bookQuontityField => Driver.FindElement(By.CssSelector("input#Quontity"));
        private IWebElement saveButtonBooks => Driver.FindElement(By.XPath("//input[@type='submit']"));
        private IWebElement detailsButtonBooks => Driver.FindElement(By.XPath("//a[@href='/Books/Details/1267']"));
        private IWebElement editeButtonBooks => Driver.FindElement(By.LinkText("Edit"));
        private IWebElement deleteButtonBooks => Driver.FindElement(By.XPath("//a[@href='/api/Users/1189']"));
        private IWebElement deleteButtonComfirmBooks => Driver.FindElement(By.XPath("//input[@value='Delete']"));
        private IWebElement acceptCookiesButton => Driver.FindElement(By.XPath("//*[@class='btn btn-default navbar-btn']"));
        public BooksPage(IWebDriver webDriver) : base(webDriver)
        {
        }

        public BooksPage VerifyPage(string expectedText)
        {
            // NOTE: Aftrer bug with ID: "XYZ1" is fixed change title on "Books"
            Assert.IsTrue(
                pageTitle.Text == expectedText
            );
            return this;
        }

        public BooksPage ClickBooksPage()
        { 
            pageBooks.Click();
            return this;
        }
        public BooksPage ClickLibrary()
        {
            libraryNavBar.Click();
            return this;
        }

        public BooksPage ClickCreateNewBook()
        {
            createNewBookButton.Click();
            Thread.Sleep(1000);
            return this;
        }

        public BooksPage InsertName(string name)
        {
            bookNameField.SendKeys(name);
            return this;
        }

        public BooksPage InsertAuthor(string author)
        {
            bookAuthorField.SendKeys(author);
            return this;
        }

        public BooksPage InsertGenere(string genere)
        {
            bookGenereField.SendKeys(genere);
            return this;
        }

        public BooksPage InsertQuontity(string quontity)
        {
            bookQuontityField.SendKeys(quontity);
            return this;
        }
        public BooksPage ClickBookSaveButton()
        {
            saveButtonBooks.Click();
            return this;
        }

        public BooksPage ClickDetailsButton()
        {
            detailsButtonBooks.Click();
            return this;
        }

        public BooksPage ClickEditButton()
        {
            editeButtonBooks.Click();
            return this;
        }
        public BooksPage ClickDeleteButton()
        {
            deleteButtonBooks.Click();
            return this;
        }
        public BooksPage ClickDeleteButtonConfirm()
        {
            deleteButtonComfirmBooks.Click();
            return this;
        }
        public BooksPage AcceptCookiesButton()
        {
            try
            {
                Driver.FindElement(By.XPath("//*[@class='btn btn-default navbar-btn']"));
                Thread.Sleep(1000);
                acceptCookiesButton.Click();
                return this;
            }
            catch (NoSuchElementException e)
            {

                return this;
            }
        }
    }
}