﻿using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Immedis.Page
{
    public class UsersPage : BasePage
    {
        private IWebElement pageTitle => Driver.FindElement(By.TagName("h2"));

        private IWebElement libraryNavBar => Driver.FindElement(By.ClassName("navbar-brand"));
        private IWebElement createNewUserButton => Driver.FindElement(By.LinkText("Create New"));

        private IWebElement userNameField => Driver.FindElement(By.CssSelector("input#Name"));

        private IWebElement saveButtonUser => Driver.FindElement(By.XPath("//input[@type='submit']"));

        private IWebElement detailsButtonUser => Driver.FindElement(By.XPath("//table[@class='table']/tbody[1]/tr[915]/td[2]/a[2]"));

        private IWebElement editeButtonUsername => Driver.FindElement(By.LinkText("Edit"));

        private IWebElement deleteButtonUser => Driver.FindElement(By.XPath("//a[@href='/api/Users/1189']"));

        private IWebElement deleteButtonComfirmUser => Driver.FindElement(By.XPath("//input[@value='Delete']"));

        private IWebElement acceptCookiesButton => Driver.FindElement(By.XPath("//*[@class='btn btn-default navbar-btn']"));

        public UsersPage(IWebDriver webDriver) : base(webDriver)
        {
        }

        public UsersPage VerifyPage(string expectedText)
        {
            // NOTE: Aftrer bug with ID: "XYZ1" is fixed change title on "Users"
            Assert.IsTrue(
                pageTitle.Text == expectedText
            );
            return this;
        }

        public UsersPage ClickLibrary()
        {
            libraryNavBar.Click();
            return this;
        }

        public UsersPage ClickCreateNewUser()
        {
            createNewUserButton.Click();
            Thread.Sleep(1000);
            return this;
        }

        public UsersPage InsertName(string name)
        {
            userNameField.SendKeys(name);
            return this;
        }
        public UsersPage ClickUserSaveButton()
        {
            saveButtonUser.Click();
            return this;
        }

        public UsersPage ClickDetailsButton()
        {
            detailsButtonUser.Click();
            return this;
        }

        public UsersPage ClickEditButton()
        {
            editeButtonUsername.Click();
            return this;
        }
        public UsersPage ClickDeleteButton()
        {
            deleteButtonUser.Click();
            return this;
        }
        public UsersPage ClickDeleteButtonConfirmUser()
        {
            deleteButtonComfirmUser.Click();
            return this;
        }
        public UsersPage AcceptCookiesButton()
        {
            try
            {
                Driver.FindElement(By.XPath("//*[@class='btn btn-default navbar-btn']"));
                Thread.Sleep(1000);
                acceptCookiesButton.Click();
                return this;
            }
            catch (NoSuchElementException e)
            {

                return this;
            }                                        
        }
    }
}
