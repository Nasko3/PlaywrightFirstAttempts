﻿using OpenQA.Selenium;

namespace Immedis.Page
{
    public class LoginPage : BasePage
    {
        private const string baseURL = "https://qa-task.immedis.com/";
        private IWebElement pageTitle => Driver.FindElement(By.TagName("h1"));
        private IWebElement usernameField => Driver.FindElement(By.XPath("//input[@name='username']"));
        private IWebElement passwordField => Driver.FindElement(By.Name("password"));
        private IWebElement signInButton => Driver.FindElement(By.XPath("//div[text()='Sign In']"));
        private IWebElement signUpButton => Driver.FindElement(By.XPath("//div[text()='Sign Up']"));
        private IWebElement forgotPassLink => Driver.FindElement(By.XPath("//a[@href='/Forgot']"));

        //private IWebElement acceptCookiesButton => Driver.FindElement(By.ClassName("//*[@class='btn btn-default navbar-btn']"));
        //private IWebElement searchField => Driver.FindElement(By.Id("header_searcher_desktop_input"));
        //private IWebElement searchButton => Driver.FindElement(By.ClassName("input-group-append"));
        //private IReadOnlyCollection<IWebElement> productCards => Driver.FindElement(By.CssSelector(".productList"))
        //    .FindElements(By.CssSelector(".card"));
        //private IWebElement openCategoriesDropdownButton => Driver.FindElement(By.Id("navbarDropdownProducts"));
        //private IReadOnlyCollection<IWebElement> productCategories => Driver.FindElement(By.CssSelector("#headerMainToggler > div > div.container.headerMenuProducts > ul > li.headerMenuProducts__menu--item.nav-item.dropdown.productsMenu.show > div > div > div > div.col-lg-9.pl-0.products"))
        //    .FindElements(By.ClassName("dropdown-item"));
        //private IWebElement colorFilterButton => Driver.FindElement(By.ClassName("filterContainerMultiple")).FindElement(By.XPath("//*[text()='Spalva']"));
        //private IWebElement sizeFilterButton => Driver.FindElement(By.ClassName("filterContainerMultiple")).FindElement(By.XPath("//*[text()='Dydis']"));
        //private IWebElement addToCartButton => Driver.FindElement(By.CssSelector("#sidenav > div > div.card-body > div > div > div:nth-child(2) > div > div.itemActionBlock > div.itemButtons > button.addToCart.btn.btn-yellow.btn-block.btn-icon.text-white"));
        //private IWebElement goToCartButton => Driver.FindElement(By.CssSelector("#modal > div > div > div.modal-footer.d-block > div.row.m-0 > div > div > button.goToCart.btn.btn-yellow.btn-icon.text-white"));
        //private IWebElement loginOrRegisterButton => Driver.FindElement(By.XPath("//*[text()='Prisijungti arba registruotis']"));
        //private IWebElement logoutButton => Driver.FindElement(By.XPath("//*[text()='Atsijungti']"));
        public LoginPage(IWebDriver webdriver) : base(webdriver)
        {
        }
        public LoginPage NavigateToDefaultPage()
        {
            if (Driver.Url != baseURL)
            {
                Driver.Url = baseURL;
            }
            return this;
        }
        public LoginPage VerifyPage(string expectedText)
        {
            Assert.IsTrue(
                pageTitle.Text == "Library Login"
            );
            return this;
        }
        //public LoginPage AcceptCookie()
        //{
        //    Cookie myCookie = new Cookie("CookieConsent"
        //        , "{stamp:%27xGChaLlxWj47cmgNIwWN0ODOISlFh5A+bNoSqQjL/5hZMxaa988X1w==%27%2Cnecessary:true%2Cpreferences:false%2Cstatistics:false%2Cmarketing:false%2Cver:1%2Cutc:1621010391490%2Cregion:%27lt%27}"
        //        , "www.ikea.lt"
        //        , "/"
        //        , DateTime.Now.AddDays(5));

        //    Driver.Manage().Cookies.AddCookie(myCookie);
        //    Driver.Navigate().Refresh();
        //    return this;
        //}
        public LoginPage FillUsername(string username)
        {
            usernameField.Clear();
            usernameField.SendKeys(username);
            return this;
        }

        public LoginPage FillPassword(string password)
        {
            passwordField.Clear();
            passwordField.SendKeys(password);
            return this;
        }

        public LoginPage ClickSignInButton()
        {
            signInButton.Click();
            return this;
        }

        public LoginPage ClickSignUpButton()
        {
            signUpButton.Click();
            return this;
        }
        public LoginPage ClickForgotPasswordLink()
        {
            forgotPassLink.Click();
            return this;
        }
        //public LoginPage AcceptCookiesButton()
        //{
        //   Thread.Sleep(1000);
        //   acceptCookiesButton.Click();
        //   return this;
        //}
    }
}
