﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;

namespace Immedis.Page
{
    public class GetBookPage : BasePage
    {
        private IWebElement pageTitle => Driver.FindElement(By.TagName("h2"));
        private IWebElement pageGetBooks => Driver.FindElement(By.XPath("//a[@href='/GetBook']"));
        private IWebElement libraryNavBar => Driver.FindElement(By.ClassName("navbar-brand"));
        private IWebElement createNewGetBookButton => Driver.FindElement(By.LinkText("Create New"));
        private IWebElement getBookUserIdDropdown => Driver.FindElement(By.Name("UserId"));
        private IWebElement getBookBookIdDropdown => Driver.FindElement(By.Name("BookId"));
        private IWebElement saveButtonGetBook => Driver.FindElement(By.XPath("//input[@type='submit']"));
        private IWebElement detailsButtonGetBook => Driver.FindElement(By.XPath("(//tr//td//a[text()='Details'])[1]"));
        private IWebElement editeButtonGetBook => Driver.FindElement(By.XPath("(//tr//td//a[text()='Edit'])[1]"));
        private IWebElement deleteButtonGetBook => Driver.FindElement(By.XPath("(//tr//td//a[text()='Delete'])[1]"));
        private IWebElement deleteButtonComfirmGetBook => Driver.FindElement(By.XPath("//input[@value='Delete']"));
        private IWebElement acceptCookiesButton => Driver.FindElement(By.XPath("//*[@class='btn btn-default navbar-btn']"));
        public GetBookPage(IWebDriver webDriver) : base(webDriver)
        {
        }

        public GetBookPage VerifyPage(string expectedText)
        {
            // NOTE: Aftrer bug with ID: "XYZ1" is fixed change title on "Books"
            Assert.IsTrue(
                pageTitle.Text == expectedText
            );
            return this;
        }
        public GetBookPage ClickGetBookPage()
        {
            pageGetBooks.Click();
            return this;
        }
        public GetBookPage ClickLibrary()
        {
            libraryNavBar.Click();
            return this;
        }
        public GetBookPage ClickCreateNewGetBook()
        {
            createNewGetBookButton.Click();
            Thread.Sleep(1000);
            return this;
        }
        public GetBookPage SelectBookUserIdDropdown(string UserId)
        {
            var selectElement = new SelectElement(getBookUserIdDropdown);
            selectElement.SelectByText(UserId);
            return this;
        }
        public GetBookPage SelectBookIdDropdown(string BookId)
        {
            var selectElement = new SelectElement(getBookBookIdDropdown);
            selectElement.SelectByText(BookId);
            return this;
        }
        public GetBookPage ClickGetBookSaveButton()
        {
            saveButtonGetBook.Click();
            return this;
        }
        public GetBookPage ClickDetailsButton()
        {
            detailsButtonGetBook.Click();
            return this;
        }
        public GetBookPage ClickEditButton()
        {
            editeButtonGetBook.Click();
            return this;
        }
        public GetBookPage ClickDeleteButton()
        {
            deleteButtonGetBook.Click();
            return this;
        }
        public GetBookPage ClickDeleteButtonConfirm()
        {
            deleteButtonComfirmGetBook.Click();
            return this;
        }
        public GetBookPage AcceptCookiesButton()
        {
            try
            {
                Driver.FindElement(By.XPath("//*[@class='btn btn-default navbar-btn']"));
                Thread.Sleep(1000);
                acceptCookiesButton.Click();
                return this;
            }
            catch (NoSuchElementException e)
            {

                return this;
            }
        }
    }
}
