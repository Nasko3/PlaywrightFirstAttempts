﻿using Immedis.Page;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Immedis.TestCases
{
    [TestFixture]
    public class GetBookTest : BaseTest
    {
        private GetBookPage getBookPage;
        protected static IWebDriver Driver;
        [SetUp]
        public void SetUp()
        {
            loginPage.NavigateToDefaultPage()
                .FillUsername(AdminUser.AdminUser.TestUser.User)
                .FillPassword(AdminUser.AdminUser.TestUser.Password)
                .ClickSignInButton();
            getBookPage = new GetBookPage(driver);
            getBookPage.VerifyPage("Index");
            getBookPage.AcceptCookiesButton();
            getBookPage.ClickGetBookPage();
        }
        [TearDown]
        public void TearDown()
        {
            getBookPage.ClickLibrary();
        }
        [Test, Order(1)]
        public void CreateGetBook()
        {
            getBookPage.ClickCreateNewGetBook()
                .SelectBookUserIdDropdown("Arya Stark")
                .SelectBookIdDropdown("George Raymond Richard Martin")
                .ClickGetBookSaveButton();
        }
        [Test, Order(2)]
        public void EditBook()
        {
            getBookPage.ClickEditButton()
                .SelectBookUserIdDropdown("George Raymond Richard Martin")
                .SelectBookIdDropdown("Jon Jon")
                .ClickGetBookSaveButton();

        }
        [Test, Order(3)]
        public void DeleteBook()
        {
            getBookPage.ClickDeleteButton()
                .ClickDeleteButtonConfirm();
        }

    }
}
