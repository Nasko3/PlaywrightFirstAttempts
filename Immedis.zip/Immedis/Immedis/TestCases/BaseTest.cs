﻿using Immedis.Driver;
using Immedis.Page;
using NUnit.Framework.Interfaces;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Immedis.TestCases
{
    public class BaseTest
    {
        protected static IWebDriver driver;
        public static LoginPage loginPage;
        public static UsersPage usersPage;

        [OneTimeSetUp]
        public static void SetUp()
        {
            driver = CustomDriver.GetChromeDriver();
           // driver = CustomDriver.GetFirefoxDriver();
            loginPage = new LoginPage(driver);
            usersPage = new UsersPage(driver);
        }
 
        [OneTimeTearDown]
        public static void TearDown()
        {
            driver.Quit();
        }
    }
}