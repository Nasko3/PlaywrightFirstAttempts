﻿using Immedis.Page;
using Microsoft.VisualStudio.TestPlatform.CommunicationUtilities;
using OpenQA.Selenium;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Immedis.TestCases
{
    [TestFixture]
    public class UsersCases : BaseTest
    {
        protected static IWebDriver Driver;
        [SetUp]
        public void SetUp()
        {
            loginPage.NavigateToDefaultPage()
            .FillUsername(AdminUser.AdminUser.TestUser.User)
            .FillPassword(AdminUser.AdminUser.TestUser.Password)
            .ClickSignInButton();
            usersPage = new UsersPage(driver);
            usersPage.VerifyPage("Index");
            usersPage.AcceptCookiesButton();
        }
        [TearDown]
        public void TearDown ()
        {
            usersPage.ClickLibrary();
        }

        [Test, Order(1)]
        public void CreateUser()
        {
            usersPage.ClickCreateNewUser()
                .InsertName("Arya Stark")
                .ClickUserSaveButton();
        }

        [Test, Order(2)]
        public void EditUser()
        {
            usersPage.ClickDetailsButton()
                .ClickEditButton()
                .InsertName("Lanistan")
                .ClickUserSaveButton();

        }
        [Test, Order(3)]
        [Ignore("Bug ID XYZ - test case will be ignored until bug is fixed")]
        public void DeleteUser()
        {
            usersPage.ClickDeleteButton()
                .ClickDeleteButtonConfirmUser();
        }
    }
}
