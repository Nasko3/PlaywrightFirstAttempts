﻿using Immedis.Page;

namespace Immedis.TestCases
{
    public class LoginTest : BaseTest
    {
        [Test]
        public void TestUserLogin()
        {
            loginPage.NavigateToDefaultPage()
            .FillUsername(AdminUser.AdminUser.TestUser.User)
            .FillPassword(AdminUser.AdminUser.TestUser.Password)
            .ClickSignInButton();
            usersPage = new UsersPage(driver);
            usersPage.VerifyPage("Index");
        }
    }
}