﻿using Immedis.Page;
using OpenQA.Selenium;

namespace Immedis.TestCases
{
    [TestFixture]
    public class BooksTest : BaseTest
    {
        private BooksPage booksPage;
        protected static IWebDriver Driver;
        [SetUp]
        public void SetUp()
        {
            loginPage.NavigateToDefaultPage()
                .FillUsername(AdminUser.AdminUser.TestUser.User)
                .FillPassword(AdminUser.AdminUser.TestUser.Password)
                .ClickSignInButton();
            booksPage = new BooksPage(driver);
            booksPage.VerifyPage("Index");
            booksPage.AcceptCookiesButton();
            booksPage.ClickBooksPage();
        }
        [TearDown]
        public void TearDown()
        {
            booksPage.ClickLibrary();
        }
        [Test, Order(1)]
        public void CreateBook()
        {
            booksPage.ClickCreateNewBook()
                .InsertName("A Game of Thrones")
                .InsertAuthor("George Raymond Richard Martin")
                .InsertGenere("Action,Adventure,Fantasy")
                .InsertQuontity("5")
                .ClickBookSaveButton();
        }
        [Test, Order(2)]
        public void EditBook()
        {
            booksPage.ClickDetailsButton()
                .ClickEditButton()
                .InsertName("New ages")
                .ClickBookSaveButton();

        }
        [Test, Order(3)]
        [Ignore("bug id xyz - test case will be ignored until bug is fixed")]
        public void DeleteBook()
        {
            booksPage.ClickDeleteButton()
                .ClickDeleteButtonConfirm();
        }

    }
}
